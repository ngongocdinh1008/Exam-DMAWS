import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import OrdersList from './pages/OrdersList';
import EditOrder from './pages/EditOrder';
import AddOrder from './pages/AddOrder';

function App() {
  return (
    <Router>
        <Routes>
            <Route path="/" element={<OrdersList />} />
            <Route path="/edit-order/:id" element={<EditOrder />} />
            <Route path="/add-order" element={<AddOrder />} />
        </Routes>
    </Router>
);
}

export default App;
