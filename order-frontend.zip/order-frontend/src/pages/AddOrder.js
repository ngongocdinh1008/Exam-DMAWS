import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './AddOrder.css';

const AddOrder = () => {
    const [order, setOrder] = useState({
        itemName: '',
        itemQty: '',
        orderDelivery: '',
        orderAddress: '',
        phoneNumber: ''
    });

    const navigate = useNavigate();

    const handleChange = (e) => {
        setOrder({
            ...order,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.post('https://localhost:44337/api/Orders', order)
            .then(() => {
                navigate('/');
            })
            .catch(error => {
                console.error('There was an error adding the order!', error);
            });
    };

    return (
        <div>
            <h1>Add New Order</h1>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Item Name:</label>
                    <input
                        type="text"
                        name="itemName"
                        value={order.itemName}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>Quantity:</label>
                    <input
                        type="number"
                        name="itemQty"
                        value={order.itemQty}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>Delivery Date:</label>
                    <input
                        type="date"
                        name="orderDelivery"
                        value={order.orderDelivery.slice(0, 10)} 
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>Address:</label>
                    <input
                        type="text"
                        name="orderAddress"
                        value={order.orderAddress}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>Phone Number:</label>
                    <input
                        type="text"
                        name="phoneNumber"
                        value={order.phoneNumber}
                        onChange={handleChange}
                    />
                </div>
                <button type="submit">Add Order</button>
            </form>
        </div>
    );
};

export default AddOrder;
