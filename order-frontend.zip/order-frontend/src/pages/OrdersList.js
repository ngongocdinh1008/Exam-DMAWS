import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './OrdersList.css';

const OrdersList = () => {
    const [orders, setOrders] = useState([]);

    useEffect(() => {
        fetchOrders();
    }, []);

    const fetchOrders = () => {
        axios.get('https://localhost:44337/api/Orders')
            .then(response => {
                setOrders(response.data);
            })
            .catch(error => {
                console.error('There was an error fetching the orders!', error);
            });
    };

    const handleDelete = (id) => {
        if (window.confirm('Are you sure you want to delete this order?')) {
            axios.delete(`https://localhost:44337/api/Orders/${id}`)
                .then(() => {
                    fetchOrders(); // Refresh the list of orders
                })
                .catch(error => {
                    console.error('There was an error deleting the order!', error);
                });
        }
    };

    return (
        <div>
            <h1>Orders List</h1>
            <Link to="/add-order">Add New Order</Link>
            <table>
                <thead>
                    <tr>
                        <th>Item Code</th>
                        <th>Item Name</th>
                        <th>Quantity</th>
                        <th>Delivery Date</th>
                        <th>Address</th>
                        <th>Phone</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {orders.map(order => (
                        <tr key={order.itemCode}>
                            <td>{order.itemCode}</td>
                            <td>{order.itemName}</td>
                            <td>{order.itemQty}</td>
                            <td>{new Date(order.orderDelivery).toLocaleDateString()}</td>
                            <td>{order.orderAddress}</td>
                            <td>{order.phoneNumber}</td>
                            <td>
                                <Link to={`/edit-order/${order.itemCode}`}>Edit</Link>
                                <button onClick={() => handleDelete(order.itemCode)}>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default OrdersList;
