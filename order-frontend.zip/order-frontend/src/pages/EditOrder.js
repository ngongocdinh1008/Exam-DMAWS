import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import './EditOrder.css';

const EditOrder = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [order, setOrder] = useState({
        orderDelivery: '',
        orderAddress: ''
    });

    useEffect(() => {
        axios.get(`https://localhost:44337/api/Orders/${id}`)
            .then(response => {
                setOrder(response.data);
            })
            .catch(error => {
                console.error('There was an error fetching the order!', error);
            });
    }, [id]);

    const handleChange = (e) => {
        setOrder({
            ...order,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.put(`https://localhost:44337/api/Orders/${id}`, order)
            .then(() => {
                navigate('/');
            })
            .catch(error => {
                console.error('There was an error updating the order!', error);
            });
    };

    return (
        <div>
            <h1>Edit Order</h1>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Delivery Date:</label>
                    <input
                        type="date"
                        name="orderDelivery"
                        value={order.orderDelivery.slice(0, 10)} 
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>Address:</label>
                    <input
                        type="text"
                        name="orderAddress"
                        value={order.orderAddress}
                        onChange={handleChange}
                    />
                </div>
                <button type="submit">Update Order</button>
            </form>
        </div>
    );
};

export default EditOrder;
