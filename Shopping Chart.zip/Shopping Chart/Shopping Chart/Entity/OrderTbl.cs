﻿using System.ComponentModel.DataAnnotations;

namespace Shopping_Chart.Entity
{
    public class OrderTbl
    {
        [Key]
        public int ItemCode { get; set; } 

        [Required]
        [MaxLength(100)]
        public required string ItemName { get; set; }

        [Required]
        public int ItemQty { get; set; } 

        [Required]
        public DateTime OrderDelivery { get; set; }

        [Required]
        [MaxLength(200)]
        public required string OrderAddress { get; set; }

        [Required]
        [Phone]
        public required string PhoneNumber { get; set; } 
    }
}
