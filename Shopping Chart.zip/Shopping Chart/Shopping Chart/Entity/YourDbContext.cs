﻿using Microsoft.EntityFrameworkCore;

namespace Shopping_Chart.Entity
{
    public class YourDbContext : DbContext
    {
        public YourDbContext(DbContextOptions<YourDbContext> options)
        : base(options)
        {
        }

        public DbSet<OrderTbl> Orders { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<OrderTbl>().ToTable("OrderTbl");
            modelBuilder.Entity<OrderTbl>(entity =>
            {
                entity.HasKey(e => e.ItemCode);
                entity.Property(e => e.ItemName).IsRequired().HasMaxLength(100);
                entity.Property(e => e.ItemQty).IsRequired();
                entity.Property(e => e.OrderDelivery).IsRequired();
                entity.Property(e => e.OrderAddress).IsRequired().HasMaxLength(200);
                entity.Property(e => e.PhoneNumber).IsRequired().HasMaxLength(15);
            });
        }
    } 
}
