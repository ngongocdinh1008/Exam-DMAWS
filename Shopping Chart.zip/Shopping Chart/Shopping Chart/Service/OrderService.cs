﻿using Microsoft.EntityFrameworkCore;
using Shopping_Chart.DTO;
using Shopping_Chart.Entity;

namespace Shopping_Chart.Service
{
    public class OrderService
    {
        private readonly YourDbContext _context;

        public OrderService(YourDbContext context)
        {
            _context = context;
        }
        public async Task<List<OrderTbl>> GetAllOrdersAsync()
        {
            return await _context.Orders.ToListAsync();
        }

        public async Task<OrderTbl> GetOrderByIdAsync(int id)
        {
            return await _context.Orders.FindAsync(id);
        }
        public async Task AddOrderAsync(OrderDTO dto)
        {
            var order = new OrderTbl
            {
                ItemName = dto.ItemName,
                ItemQty = dto.ItemQty,
                OrderDelivery = dto.OrderDelivery,
                OrderAddress = dto.OrderAddress,
                PhoneNumber = dto.PhoneNumber
            };

            _context.Orders.Add(order);  
            await _context.SaveChangesAsync();
        }
        public async Task UpdateOrderAsync(int id, UpdateOrderDto dto)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                throw new KeyNotFoundException("Order not found");
            }

            order.OrderDelivery = dto.OrderDelivery;
            order.OrderAddress = dto.OrderAddress;

            _context.Orders.Update(order);
            await _context.SaveChangesAsync();
        }
        public async Task DeleteOrderAsync(int id)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                throw new KeyNotFoundException("Order not found");
            }

            _context.Orders.Remove(order);
            await _context.SaveChangesAsync();
        }
    }
}
