﻿using System.ComponentModel.DataAnnotations;

namespace Shopping_Chart.DTO
{
    public class OrderDTO
    {
        [Required]
        [MaxLength(100)]
        public string ItemName { get; set; }

        [Required]
        public int ItemQty { get; set; }

        [Required]
        public DateTime OrderDelivery { get; set; }

        [Required]
        [MaxLength(200)]
        public string OrderAddress { get; set; }

        [Required]
        [Phone]
        public string PhoneNumber { get; set; }
    }
}
