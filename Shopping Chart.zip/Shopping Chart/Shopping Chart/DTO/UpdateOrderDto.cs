﻿using System.ComponentModel.DataAnnotations;

namespace Shopping_Chart.DTO
{
    public class UpdateOrderDto
    {
        [Required]
        public DateTime OrderDelivery { get; set; }

        [Required]
        [MaxLength(200)]
        public string OrderAddress { get; set; }
    }
}
